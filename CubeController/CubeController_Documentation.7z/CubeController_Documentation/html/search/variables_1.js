var searchData=
[
  ['comfortable_5fbox_5fwoop_5fwoop_5fdelay',['COMFORTABLE_BOX_WOOP_WOOP_DELAY',['../class_cube_controller_1_1_effect.html#a21d45a2f9419ab9237a25ae0cbe5af33',1,'CubeController::Effect']]]
];
