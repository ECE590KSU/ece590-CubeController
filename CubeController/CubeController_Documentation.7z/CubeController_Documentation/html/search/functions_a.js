var searchData=
[
  ['newemptyplane',['NewEmptyPlane',['../class_cube_controller_1_1_cube.html#a940366f41383f5c6976fd8540fbe0151',1,'CubeController.Cube.NewEmptyPlane()'],['../class_cube_controller_1_1_font_handler.html#a07f14dfc8d01ccafadf1d724782f7fe9',1,'CubeController.FontHandler.NewEmptyPlane()']]]
];
