var searchData=
[
  ['dimension',['DIMENSION',['../class_cube_controller_1_1_cube.html#af8b4bed33c4b80cc1de08583ec22ae04',1,'CubeController.Cube.DIMENSION()'],['../class_cube_controller_1_1_serial_driver.html#a0ea8959c46b0fd05621375461c4d00fc',1,'CubeController.SerialDriver.DIMENSION()']]]
];
