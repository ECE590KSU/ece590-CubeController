var searchData=
[
  ['nice_5fsine_5fwave_5fdelta_5ft',['NICE_SINE_WAVE_DELTA_T',['../class_cube_controller_1_1_effect.html#a3cb2c5bf52b3d30f3ba89a53f7c2db74',1,'CubeController::Effect']]]
];
