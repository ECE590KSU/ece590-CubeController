var searchData=
[
  ['newemptyplane',['NewEmptyPlane',['../class_cube_controller_1_1_cube.html#a940366f41383f5c6976fd8540fbe0151',1,'CubeController.Cube.NewEmptyPlane()'],['../class_cube_controller_1_1_font_handler.html#a07f14dfc8d01ccafadf1d724782f7fe9',1,'CubeController.FontHandler.NewEmptyPlane()']]],
  ['nice_5fsine_5fwave_5fdelta_5ft',['NICE_SINE_WAVE_DELTA_T',['../class_cube_controller_1_1_effect.html#a3cb2c5bf52b3d30f3ba89a53f7c2db74',1,'CubeController::Effect']]],
  ['num_5ffirework_5fcomponents',['NUM_FIREWORK_COMPONENTS',['../3d_8cpp.html#ae97152c48aaed0bd0518138ab882f04c',1,'3d.cpp']]]
];
