var searchData=
[
  ['openport',['OpenPort',['../class_cube_controller_1_1_serial_driver.html#a2d67b664a1d78f7856e2c5a666205b15',1,'CubeController::SerialDriver']]],
  ['origin',['ORIGIN',['../class_cube_controller_1_1_cube.html#a5240da6a4c8c74cd3db6cc3fed582597a6d7b0f55d14f78a5611f7e00a2e3c2ec',1,'CubeController::Cube']]]
];
