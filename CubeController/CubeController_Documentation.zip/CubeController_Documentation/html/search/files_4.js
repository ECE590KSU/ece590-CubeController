var searchData=
[
  ['effect_2ecpp',['effect.cpp',['../effect_8cpp.html',1,'']]],
  ['effect_2ecs',['Effect.cs',['../_effect_8cs.html',1,'']]]
];
