var searchData=
[
  ['helix_5fbraid_5flength_5fdelta_5ft',['HELIX_BRAID_LENGTH_DELTA_T',['../class_cube_controller_1_1_effect.html#ada4abaf428db0ddfe7966c50b20a36b9',1,'CubeController::Effect']]]
];
