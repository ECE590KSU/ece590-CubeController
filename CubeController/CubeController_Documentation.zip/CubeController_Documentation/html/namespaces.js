var namespaces =
[
    [ "CubeController", "namespace_cube_controller.html", null ]
];