var class_cube_controller_1_1_effect =
[
    [ "COMFORTABLE_BOX_WOOP_WOOP_DELAY", "class_cube_controller_1_1_effect.html#a21d45a2f9419ab9237a25ae0cbe5af33", null ],
    [ "HELIX_BRAID_LENGTH_DELTA_T", "class_cube_controller_1_1_effect.html#ada4abaf428db0ddfe7966c50b20a36b9", null ],
    [ "NICE_SINE_WAVE_DELTA_T", "class_cube_controller_1_1_effect.html#a3cb2c5bf52b3d30f3ba89a53f7c2db74", null ],
    [ "PI", "class_cube_controller_1_1_effect.html#aca0941e884dbcae4f82b151840ca53d6", null ],
    [ "RIPPLE_INTERVAL", "class_cube_controller_1_1_effect.html#ac2aa211f00a7ac4dfd9fdc5ee6f67c14", null ],
    [ "TEST_WAVE_ITERATIONS", "class_cube_controller_1_1_effect.html#af2f23cddaf032617573d46642b14bc76", null ],
    [ "WAVE_CONSTANT", "class_cube_controller_1_1_effect.html#aea4ab35024dd6e92f36199862aedc829", null ]
];