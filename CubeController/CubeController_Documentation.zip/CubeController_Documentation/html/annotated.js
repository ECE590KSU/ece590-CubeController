var annotated =
[
    [ "CubeController", "namespace_cube_controller.html", "namespace_cube_controller" ]
];